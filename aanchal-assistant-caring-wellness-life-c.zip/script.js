/**
 * AANCHAL ASSISTANT — CORE SCRIPT
 * Empathetic Personal & Maternal Life Companion
 * Zero External Dependencies
 */

document.addEventListener("DOMContentLoaded", () => {
  // ---------------------------------------------------------
  // 1. STATE INITIALIZATION (Local Storage Fallback Safe)
  // ---------------------------------------------------------
  const state = {
    theme: safeGet("aanchal_theme", "warm"),
    persona: safeGet("aanchal_persona", "warm"),
    voiceEnabled: safeGet("aanchal_voice", "true") === "true",
    waterCount: parseInt(safeGet("aanchal_water", "0"), 10) || 0,
    waterGoal: 8,
    mood: safeGet("aanchal_mood", ""),
    guardian: safeGetJSON("aanchal_guardian", { name: "", phone: "" }),
    medications: safeGetJSON("aanchal_meds", [
      { id: 1, name: "Folic Acid / Multivitamin", time: "Morning after breakfast", notes: "Essential for vitality & maternal health", done: false },
      { id: 2, name: "Calcium & Vitamin D", time: "Evening 8:00 PM", notes: "Do not take concurrently with iron", done: false }
    ]),
    tasks: safeGetJSON("aanchal_tasks", [
      { id: 101, text: "Gentle 15-minute sunlit morning stretch", category: "Wellness", completed: true },
      { id: 102, text: "Hydrate with 2 glasses of lukewarm water", category: "Health", completed: true },
      { id: 103, text: "Midday mindful breathing check-in", category: "Wellness", completed: false },
      { id: 104, text: "Review evening calm & nutrition plan", category: "Family", completed: false }
    ]),
    activeTab: "chat",
    activeTaskFilter: "all"
  };

  function safeGet(key, defaultVal) {
    try {
      const val = localStorage.getItem(key);
      return val !== null ? val : defaultVal;
    } catch (e) {
      return defaultVal;
    }
  }

  function safeSet(key, val) {
    try {
      localStorage.setItem(key, val);
    } catch (e) {}
  }

  function safeGetJSON(key, defaultVal) {
    try {
      const val = localStorage.getItem(key);
      return val ? JSON.parse(val) : defaultVal;
    } catch (e) {
      return defaultVal;
    }
  }

  function safeSetJSON(key, val) {
    try {
      localStorage.setItem(key, JSON.stringify(val));
    } catch (e) {}
  }

  // ---------------------------------------------------------
  // 2. THEME CONTROLLER
  // ---------------------------------------------------------
  const themeToggleBtn = document.getElementById("themeToggleBtn");
  applyTheme(state.theme);

  themeToggleBtn.addEventListener("click", () => {
    state.theme = state.theme === "dark" ? "warm" : "dark";
    applyTheme(state.theme);
    safeSet("aanchal_theme", state.theme);
  });

  function applyTheme(theme) {
    document.body.setAttribute("data-theme", theme);
  }

  // ---------------------------------------------------------
  // 3. TAB NAVIGATION
  // ---------------------------------------------------------
  const tabButtons = document.querySelectorAll(".module-tabs .tab-item");
  const tabPanels = document.querySelectorAll(".tab-panel");

  tabButtons.forEach(btn => {
    btn.addEventListener("click", () => {
      const target = btn.dataset.tab;
      switchTab(target);
    });
  });

  function switchTab(tabId) {
    state.activeTab = tabId;
    tabButtons.forEach(b => b.classList.toggle("active", b.dataset.tab === tabId));
    tabPanels.forEach(p => p.classList.toggle("active", p.id === `pane-${tabId}`));
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  // ---------------------------------------------------------
  // 4. PERSONA & VOICE CONFIG
  // ---------------------------------------------------------
  const personaSelect = document.getElementById("personaSelect");
  const personaLabel = document.getElementById("personaLabel");
  const voiceToggleBtn = document.getElementById("voiceToggleBtn");
  const voiceStatusText = document.getElementById("voiceStatusText");

  if (personaSelect) {
    personaSelect.value = state.persona;
    updatePersonaLabel(state.persona);
    personaSelect.addEventListener("change", (e) => {
      state.persona = e.target.value;
      safeSet("aanchal_persona", state.persona);
      updatePersonaLabel(state.persona);
    });
  }

  function updatePersonaLabel(p) {
    if (p === "warm") {
      personaLabel.textContent = "Aanchal: Warm & Maternal Companion";
    } else if (p === "doctor") {
      personaLabel.textContent = "Aanchal: Clinical & Wellness Guide";
    } else {
      personaLabel.textContent = "Aanchal: Energetic & Motivating Companion";
    }
  }

  function updateVoiceButtonState() {
    if (state.voiceEnabled) {
      voiceToggleBtn.classList.add("active");
      voiceStatusText.textContent = "Voice On";
    } else {
      voiceToggleBtn.classList.remove("active");
      voiceStatusText.textContent = "Voice Off";
    }
  }
  updateVoiceButtonState();

  voiceToggleBtn.addEventListener("click", () => {
    state.voiceEnabled = !state.voiceEnabled;
    safeSet("aanchal_voice", String(state.voiceEnabled));
    updateVoiceButtonState();
    if (!state.voiceEnabled && "speechSynthesis" in window) {
      window.speechSynthesis.cancel();
    }
  });

  function speakText(text) {
    if (!state.voiceEnabled || !("speechSynthesis" in window)) return;
    try {
      window.speechSynthesis.cancel();
      // Strip markdown asterisks or HTML tags
      const clean = text.replace(/[*#_]/g, "").replace(/<[^>]*>?/gm, "");
      const utterance = new SpeechSynthesisUtterance(clean);
      utterance.rate = 0.95;
      utterance.pitch = 1.05;

      const voices = window.speechSynthesis.getVoices();
      // Try to pick a gentle voice
      const preferred = voices.find(v => v.lang.startsWith("en-IN") || v.name.includes("Natural") || v.name.includes("Female"));
      if (preferred) utterance.voice = preferred;

      window.speechSynthesis.speak(utterance);
    } catch (e) {
      // Speech synthesis error ignored safely
    }
  }

  // ---------------------------------------------------------
  // 5. CHAT ENGINE WITH INTELLIGENT RULE MAPPING
  // ---------------------------------------------------------
  const chatMessages = document.getElementById("chatMessages");
  const chatForm = document.getElementById("chatForm");
  const userInput = document.getElementById("userInput");
  const typingIndicator = document.getElementById("typingIndicator");

  // Handle suggested prompt chips & action pills
  document.addEventListener("click", (e) => {
    const chip = e.target.closest(".chip, .action-tag");
    if (chip && chip.dataset.prompt) {
      userInput.value = chip.dataset.prompt;
      submitUserQuery(chip.dataset.prompt);
    }
  });

  chatForm.addEventListener("submit", (e) => {
    e.preventDefault();
    const query = userInput.value.trim();
    if (!query) return;
    submitUserQuery(query);
  });

  function submitUserQuery(text) {
    appendMessage(text, "user");
    userInput.value = "";

    // Show typing
    typingIndicator.style.display = "flex";
    chatMessages.scrollTop = chatMessages.scrollHeight;

    setTimeout(() => {
      typingIndicator.style.display = "none";
      const reply = generateAanchalResponse(text, state.persona);
      appendMessage(reply.html, "assistant", reply.actions);
      speakText(reply.plain);
    }, 550);
  }

  function appendMessage(content, sender, actionTags = []) {
    const group = document.createElement("div");
    group.className = `msg-group ${sender}`;

    const now = new Date();
    const timeStr = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

    let actionsHtml = "";
    if (actionTags && actionTags.length > 0) {
      actionsHtml = `<div class="msg-actions">` +
        actionTags.map(act => `<button class="action-tag" data-prompt="${escapeHtml(act.prompt)}">${escapeHtml(act.label)}</button>`).join("") +
        `</div>`;
    }

    group.innerHTML = `
      <div class="msg-avatar">
        <span>${sender === 'assistant' ? '🌸' : '👤'}</span>
      </div>
      <div class="msg-bubble">
        ${sender === 'assistant' ? content : `<p>${escapeHtml(content)}</p>`}
        ${actionsHtml}
        <span class="msg-time">${timeStr}</span>
      </div>
    `;

    chatMessages.appendChild(group);
    chatMessages.scrollTop = chatMessages.scrollHeight;
  }

  function escapeHtml(str) {
    return str.replace(/[&<>"']/g, m => ({
      '&': '&amp;',
      '<': '&lt;',
      '>': '&gt;',
      '"': '&quot;',
      "'": '&#39;'
    }[m]));
  }

  // Knowledge base and empathetic response generator
  function generateAanchalResponse(rawQuery, persona) {
    const q = rawQuery.toLowerCase();

    // 1. Stress / Anxiety / Overwhelmed
    if (q.includes("stress") || q.includes("anxious") || q.includes("overwhelm") || q.includes("panic") || q.includes("cry") || q.includes("sad")) {
      return {
        plain: "Take a deep gentle breath with me right now. You are carrying so much, and it is completely natural to feel tired. Drink half a glass of warm water, uncurl your shoulders, and let us do the 4-7-8 breathing practice together.",
        html: `
          <p><strong>🌸 Take a soft, gentle breath with me right now.</strong></p>
          <p>You have been carrying so many thoughts and responsibilities. Let your shoulders drop, release the tension in your jaw, and know that you are safe in this moment.</p>
          <p>Would you like to step into our <em>Breathe &amp; Calm Sanctuary</em> right now, or try a 2-minute grounding exercise?</p>
        `,
        actions: [
          { label: "🕊️ Go to Breathing Exercise", prompt: "Open breathing exercise" },
          { label: "🍵 Warm Tea & Comfort Tips", prompt: "Suggest herbal calming remedies" }
        ]
      };
    }

    // 2. Pregnancy & Trimesters
    if (q.includes("pregnan") || q.includes("trimester") || q.includes("baby") || q.includes("nausea") || q.includes("morning sickness")) {
      return {
        plain: "Maternal care is our highest blessing. During the first trimester, prioritize folate, stay hydrated in small sips to manage nausea, and avoid heavy strenuous lifting. Rest without feeling guilty.",
        html: `
          <p><strong>🤰 Gentle Care for You &amp; Your Little Miracle</strong></p>
          <p>Every phase of motherhood is sacred. Here are key pillars for your wellness:</p>
          <ul>
            <li><strong>Morning Nausea:</strong> Keep dry crackers or roasted ginger fennel tea by your bedside before getting up.</li>
            <li><strong>Vital Nutrition:</strong> Folic acid (400–600 mcg daily), iron-rich greens (spinach, beetroot), and ample hydration.</li>
            <li><strong>Hydration:</strong> Drink small sips regularly rather than big glasses at once to prevent reflux.</li>
          </ul>
          <p>You can also check our <em>Health Hub LMP Tracker</em> to see your baby's weekly development!</p>
        `,
        actions: [
          { label: "🥑 2nd Trimester Nutrition", prompt: "What should I eat during pregnancy second trimester?" },
          { label: "💊 Check Vitamins Log", prompt: "Show my medicine schedule" }
        ]
      };
    }

    // 3. Period / Menstrual Cramps / PMS
    if (q.includes("period") || q.includes("cramp") || q.includes("pms") || q.includes("cycle") || q.includes("menstru")) {
      return {
        plain: "Period discomfort can be so draining. Please place a warm water bag on your lower abdomen, sip warm ajwain or ginger cinnamon water, and take gentle rest.",
        html: `
          <p><strong>🌸 Gentle Relief for Cramps &amp; Cycle Discomfort</strong></p>
          <p>Your body is working hard. Here is Aanchal's comforting routine:</p>
          <ul>
            <li><strong>Warmth:</strong> Apply a hot water compress on your pelvic area or lower back.</li>
            <li><strong>Warm Ajwain &amp; Ginger Infusion:</strong> Boil half a spoon of carom seeds (ajwain) with fresh ginger slice; sip warm to ease uterine muscle spasms.</li>
            <li><strong>Magnesium Support:</strong> Dark chocolate, soaked almonds, and bananas provide muscular comfort.</li>
          </ul>
        `,
        actions: [
          { label: "📅 Track Next Period", prompt: "How do I predict my next period?" },
          { label: "🍵 Ajwain Remedy Recipe", prompt: "Tell me more about ajwain tea" }
        ]
      };
    }

    // 4. Bedtime / Insomnia / Sleep
    if (q.includes("sleep") || q.includes("bedtime") || q.includes("insomnia") || q.includes("night") || q.includes("tired")) {
      return {
        plain: "Good restorative sleep restores your immune strength. Turn off screen blue light 30 minutes before sleep, wash your feet with lukewarm water, and listen to silence.",
        html: `
          <p><strong>🌙 Aanchal's Evening Wind-Down Ritual</strong></p>
          <ul>
            <li>Dim the room lights 40 minutes prior to sleeping.</li>
            <li>Sip warm turmeric milk with a pinch of nutmeg (Jaiphal) or chamomile infusion.</li>
            <li>Gently massage the soles of your feet with warm sesame or coconut oil.</li>
            <li>Release today's worries: tomorrow is a fresh page.</li>
          </ul>
        `,
        actions: [
          { label: "🕊️ 4-7-8 Breathing", prompt: "Open breathing exercise" },
          { label: "☀️ Morning Routine Tomorrow", prompt: "Suggest a healthy morning routine" }
        ]
      };
    }

    // 5. Water / Hydration
    if (q.includes("water") || q.includes("hydration") || q.includes("drink")) {
      return {
        plain: `You have completed ${state.waterCount} out of ${state.waterGoal} glasses of water today. Staying hydrated keeps your energy stable and eases headaches.`,
        html: `
          <p><strong>💧 Hydration Check</strong></p>
          <p>You have logged <strong>${state.waterCount} / ${state.waterGoal} glasses</strong> today.</p>
          <p><em>Tip:</em> If plain water feels unexciting, infuse it with fresh cucumber slices, mint leaves, or a squeeze of lemon.</p>
        `,
        actions: [
          { label: "+1 Glass Water Now", prompt: "Add one glass of water" }
        ]
      };
    }

    if (q.includes("add one glass") || q.includes("add water")) {
      state.waterCount = Math.min(state.waterGoal, state.waterCount + 1);
      updateWaterUI();
      safeSet("aanchal_water", state.waterCount);
      return {
        plain: `Wonderful! Added 1 glass. You are now at ${state.waterCount} glasses of water today. Keep it up!`,
        html: `<p>✨ <strong>Hydration Updated!</strong> You are now at <strong>${state.waterCount} / ${state.waterGoal}</strong> glasses. Your cells thank you!</p>`,
        actions: []
      };
    }

    // 6. Emergency or Danger words
    if (q.includes("help") || q.includes("danger") || q.includes("emergency") || q.includes("police") || q.includes("unsafe") || q.includes("accident")) {
      return {
        plain: "If you are in danger or have a medical urgency, press our SOS Shield button immediately or dial 112 or 1091. You are not alone.",
        html: `
          <p><strong>🚨 Safety &amp; Emergency Alert</strong></p>
          <p>If you feel unsafe or have an urgent medical crisis, please activate our <strong>SOS Shield</strong> at the top right of your screen immediately.</p>
          <p>Direct emergency hotlines:</p>
          <ul>
            <li><strong>112</strong> — National All-in-One Emergency</li>
            <li><strong>1091</strong> — Women Safety Cell Helpline</li>
            <li><strong>102 / 108</strong> — Emergency Medical Ambulance</li>
          </ul>
        `,
        actions: [
          { label: "🚨 Launch SOS Shield", prompt: "Open SOS Shield" }
        ]
      };
    }

    // 7. Open SOS directly
    if (q.includes("open sos shield")) {
      openSosModal();
      return {
        plain: "Opening the SOS Shield modal now. Stay calm, we are here.",
        html: `<p>🛡️ <em>Opening Emergency SOS Shield interface...</em></p>`,
        actions: []
      };
    }

    // 8. Open breathing directly
    if (q.includes("open breathing exercise")) {
      switchTab("calm");
      return {
        plain: "Switching to the Breathe & Calm sanctuary now.",
        html: `<p>🕊️ <em>Navigating to the Breathe & Calm Sanctuary...</em></p>`,
        actions: []
      };
    }

    // Default Empathetic Persona responses
    if (persona === "doctor") {
      return {
        plain: "I hear you. Maintaining consistent bio-rhythms, balanced glycemic index meals, and monitored micronutrients will stabilize your vitality. Let's look closer at your symptoms.",
        html: `
          <p><strong>🩺 Clinical Wellness Observation</strong></p>
          <p>Regarding "<em>${escapeHtml(rawQuery)}</em>":</p>
          <p>Always note physiological patterns: sleep quality, hydration balance, and stress markers. If you are tracking hormonal or chronic symptoms, note their daily duration.</p>
          <p>Check our <strong>Health Hub</strong> tab to update your daily vitals and medication checklist.</p>
        `,
        actions: [
          { label: "💊 Log Supplements", prompt: "Show my medicine schedule" },
          { label: "💧 Check Water Intake", prompt: "How much water did I drink?" }
        ]
      };
    } else if (persona === "cheer") {
      return {
        plain: "You have got this! Every small mindful choice you make today builds a happier, healthier you. Let's keep your spirits high and make today wonderful!",
        html: `
          <p><strong>☀️ You are doing amazing!</strong></p>
          <p>Never forget how resilient you are. Even on quiet days, taking care of yourself is a big win!</p>
          <p>What is one uplifting goal we can achieve together in the next hour?</p>
        `,
        actions: [
          { label: "✨ Add a Quick Routine", prompt: "Suggest a healthy morning routine" },
          { label: "🌸 Today's Mood Check", prompt: "I want to log my mood" }
        ]
      };
    }

    // Standard Warm Maternal Response
    return {
      plain: "I am listening with an open heart. Whatever you are going through, remember to treat yourself with patience and kindness. Let me know how I can comfort you.",
      html: `
        <p><strong>🌸 Aanchal is with you.</strong></p>
        <p>I hear you on "<em>${escapeHtml(rawQuery)}</em>". Remember, taking care of yourself is not selfish—it is the foundation of everything you give to those you love.</p>
        <p>Would you like home wellness remedies, cycle tracking, or a gentle breathing pause?</p>
      `,
      actions: [
        { label: "🌿 Explore Remedies", prompt: "What natural remedies can help with fatigue?" },
        { label: "🌸 Daily Affirmation", prompt: "Give me an encouraging affirmation" }
      ]
    };
  }

  // ---------------------------------------------------------
  // 6. SPEECH RECOGNITION (Hands-Free Mic)
  // ---------------------------------------------------------
  const micBtn = document.getElementById("micBtn");
  const micStatusAlert = document.getElementById("micStatusAlert");
  let recognition = null;
  let isListening = false;

  const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;

  if (SpeechRecognition) {
    recognition = new SpeechRecognition();
    recognition.continuous = false;
    recognition.interimResults = false;
    recognition.lang = "en-IN";

    recognition.onstart = () => {
      isListening = true;
      micBtn.classList.add("listening");
      micStatusAlert.textContent = "Listening... Speak your question to Aanchal.";
    };

    recognition.onresult = (e) => {
      const transcript = e.results[0][0].transcript;
      userInput.value = transcript;
      micStatusAlert.textContent = "";
      submitUserQuery(transcript);
    };

    recognition.onerror = () => {
      isListening = false;
      micBtn.classList.remove("listening");
      micStatusAlert.textContent = "Microphone error. Please type your message.";
      setTimeout(() => { micStatusAlert.textContent = ""; }, 3000);
    };

    recognition.onend = () => {
      isListening = false;
      micBtn.classList.remove("listening");
      micStatusAlert.textContent = "";
    };

    micBtn.addEventListener("click", () => {
      if (isListening) {
        recognition.stop();
      } else {
        recognition.start();
      }
    });
  } else {
    micBtn.addEventListener("click", () => {
      micStatusAlert.textContent = "Speech recognition is not supported in this browser. Please type.";
      setTimeout(() => { micStatusAlert.textContent = ""; }, 3000);
    });
  }

  // ---------------------------------------------------------
  // 7. HEALTH HUB: MOOD, WATER & MEDICINES
  // ---------------------------------------------------------
  // Today's date badge
  const todayDateLabel = document.getElementById("todayDateLabel");
  if (todayDateLabel) {
    const today = new Date();
    todayDateLabel.textContent = today.toLocaleDateString(undefined, { weekday: 'short', month: 'short', day: 'numeric' });
  }

  // Affirmations pool
  const affirmations = [
    "You are doing enough. Give your mind and body the softness they deserve today.",
    "Your breath is your anchor; every moment is a chance to begin anew.",
    "Gentle boundaries are an act of self-preservation and deep respect.",
    "Your health and peace of mind matter more than rushing.",
    "Honor your body’s rhythm. Rest is productive and sacred."
  ];
  const affirmationBox = document.getElementById("affirmationBox");
  if (affirmationBox) {
    const randomAffirmation = affirmations[Math.floor(Math.random() * affirmations.length)];
    affirmationBox.textContent = `"${randomAffirmation}"`;
  }

  // Mood buttons
  const moodPills = document.querySelectorAll(".mood-pill");
  const moodFeedback = document.getElementById("moodFeedback");

  if (state.mood) {
    moodPills.forEach(p => {
      if (p.dataset.mood === state.mood) p.classList.add("active");
    });
  }

  moodPills.forEach(pill => {
    pill.addEventListener("click", () => {
      moodPills.forEach(p => p.classList.remove("active"));
      pill.classList.add("active");
      const mood = pill.dataset.mood;
      state.mood = mood;
      safeSet("aanchal_mood", mood);

      let msg = "";
      if (mood === "Serene") msg = "🌸 Peaceful mind, joyful spirit. May your gentle aura remain intact today.";
      else if (mood === "Happy") msg = "☀️ Aanchal celebrates your smile! Radiate that sunshine.";
      else if (mood === "Exhausted") msg = "🥱 You have given your best. Sip warm water and permit yourself to rest early.";
      else if (mood === "Anxious") msg = "🌧️ Take a long breath. Aanchal is right here. Try our 4-7-8 Breathing sanctuary.";
      else if (mood === "Unwell") msg = "🩹 Warm nourishment, herbal fluids, and tender rest are your medicine today.";

      moodFeedback.textContent = msg;
    });
  });

  // Water Tracker
  const waterCurrent = document.getElementById("waterCurrent");
  const waterProgress = document.getElementById("waterProgress");
  const addWaterBtn = document.getElementById("addWaterBtn");
  const subWaterBtn = document.getElementById("subWaterBtn");
  const resetWaterBtn = document.getElementById("resetWaterBtn");

  function updateWaterUI() {
    if (!waterCurrent) return;
    waterCurrent.textContent = state.waterCount;
    const pct = Math.min(100, Math.round((state.waterCount / state.waterGoal) * 100));
    waterProgress.style.width = `${pct}%`;
  }
  updateWaterUI();

  addWaterBtn?.addEventListener("click", () => {
    if (state.waterCount < 16) {
      state.waterCount++;
      safeSet("aanchal_water", state.waterCount);
      updateWaterUI();
    }
  });

  subWaterBtn?.addEventListener("click", () => {
    if (state.waterCount > 0) {
      state.waterCount--;
      safeSet("aanchal_water", state.waterCount);
      updateWaterUI();
    }
  });

  resetWaterBtn?.addEventListener("click", () => {
    state.waterCount = 0;
    safeSet("aanchal_water", 0);
    updateWaterUI();
  });

  // Medicine List
  const medList = document.getElementById("medList");
  const noMedsHint = document.getElementById("noMedsHint");
  const openAddMedModal = document.getElementById("openAddMedModal");
  const addMedModal = document.getElementById("addMedModal");
  const closeMedModalBtn = document.getElementById("closeMedModalBtn");
  const addMedForm = document.getElementById("addMedForm");

  function renderMeds() {
    if (!medList) return;
    medList.innerHTML = "";
    if (state.medications.length === 0) {
      noMedsHint.style.display = "block";
      return;
    }
    noMedsHint.style.display = "none";

    state.medications.forEach(med => {
      const li = document.createElement("li");
      li.className = `item-row ${med.done ? "done" : ""}`;
      li.innerHTML = `
        <div class="item-left">
          <input type="checkbox" ${med.done ? "checked" : ""} data-id="${med.id}" class="med-checkbox">
          <div>
            <div class="item-name">${escapeHtml(med.name)}</div>
            <div class="item-sub">${escapeHtml(med.time)} ${med.notes ? `&bull; ${escapeHtml(med.notes)}` : ''}</div>
          </div>
        </div>
        <button class="del-btn" data-del-id="${med.id}" title="Remove pill">&times;</button>
      `;
      medList.appendChild(li);
    });
  }
  renderMeds();

  medList?.addEventListener("change", (e) => {
    if (e.target.classList.contains("med-checkbox")) {
      const id = parseInt(e.target.dataset.id, 10);
      const targetMed = state.medications.find(m => m.id === id);
      if (targetMed) {
        targetMed.done = e.target.checked;
        safeSetJSON("aanchal_meds", state.medications);
        renderMeds();
      }
    }
  });

  medList?.addEventListener("click", (e) => {
    const delBtn = e.target.closest("[data-del-id]");
    if (delBtn) {
      const id = parseInt(delBtn.dataset.delId, 10);
      state.medications = state.medications.filter(m => m.id !== id);
      safeSetJSON("aanchal_meds", state.medications);
      renderMeds();
    }
  });

  openAddMedModal?.addEventListener("click", () => {
    addMedModal.classList.add("open");
  });

  closeMedModalBtn?.addEventListener("click", () => {
    addMedModal.classList.remove("open");
  });

  addMedForm?.addEventListener("submit", (e) => {
    e.preventDefault();
    const name = document.getElementById("medName").value.trim();
    const time = document.getElementById("medTime").value.trim();
    const notes = document.getElementById("medNotes").value.trim();
    if (!name) return;

    state.medications.push({
      id: Date.now(),
      name,
      time,
      notes,
      done: false
    });
    safeSetJSON("aanchal_meds", state.medications);
    renderMeds();
    addMedForm.reset();
    addMedModal.classList.remove("open");
  });

  // ---------------------------------------------------------
  // 8. CYCLE PREDICTOR & PREGNANCY STAGE CALCULATOR
  // ---------------------------------------------------------
  const cycleForm = document.getElementById("cycleForm");
  const cycleResults = document.getElementById("cycleResults");
  const resNextPeriod = document.getElementById("resNextPeriod");
  const resFertile = document.getElementById("resFertile");
  const resAdvice = document.getElementById("resAdvice");

  cycleForm?.addEventListener("submit", (e) => {
    e.preventDefault();
    const lmpInput = document.getElementById("lastPeriodDate").value;
    const cycleLength = parseInt(document.getElementById("cycleLength").value, 10) || 28;
    if (!lmpInput) return;

    const lastDate = new Date(lmpInput);
    const nextDate = new Date(lastDate);
    nextDate.setDate(lastDate.getDate() + cycleLength);

    const ovulationDate = new Date(nextDate);
    ovulationDate.setDate(nextDate.getDate() - 14);

    const fertileStart = new Date(ovulationDate);
    fertileStart.setDate(ovulationDate.getDate() - 4);
    const fertileEnd = new Date(ovulationDate);
    fertileEnd.setDate(ovulationDate.getDate() + 1);

    const options = { month: 'short', day: 'numeric', year: 'numeric' };
    resNextPeriod.textContent = nextDate.toLocaleDateString(undefined, options);
    resFertile.textContent = `${fertileStart.toLocaleDateString(undefined, { month: 'short', day: 'numeric' })} – ${fertileEnd.toLocaleDateString(undefined, options)}`;
    resAdvice.textContent = "Keep chamomile or ajwain tea handy 2 days prior. Stay well-hydrated to ease bloating.";

    cycleResults.style.display = "flex";
  });

  // Pregnancy Milestone Calculator
  const calcPregBtn = document.getElementById("calcPregBtn");
  const pregInfoResult = document.getElementById("pregInfoResult");
  const pregWeekTitle = document.getElementById("pregWeekTitle");
  const pregBabySize = document.getElementById("pregBabySize");
  const pregDescription = document.getElementById("pregDescription");
  const pregTipsList = document.getElementById("pregTipsList");

  calcPregBtn?.addEventListener("click", () => {
    const lmpVal = document.getElementById("lmpDate").value;
    if (!lmpVal) {
      alert("Please select the first day of your last period (LMP).");
      return;
    }

    const lmp = new Date(lmpVal);
    const today = new Date();
    const diffTime = today - lmp;
    const diffDays = Math.floor(diffTime / (1000 * 60 * 60 * 24));
    const weeks = Math.floor(diffDays / 7);

    if (weeks < 1 || weeks > 42) {
      alert("The calculated timeline is outside the standard 1-42 week pregnancy span. Please verify the date entered.");
      return;
    }

    pregInfoResult.style.display = "block";

    let trimester = 1;
    let sizeDesc = "Seed 🌾";
    let desc = "Early cellular growth. Organs and neural tube are beginning to form.";
    let tips = [
      "Take daily prescribed Folic Acid (prevents neural defects).",
      "Sip warm ginger water in small amounts for morning sickness.",
      "Get plenty of rest; progesterone causes sudden fatigue."
    ];

    if (weeks >= 13 && weeks <= 27) {
      trimester = 2;
      sizeDesc = "Lemon to Papaya 🥭";
      desc = "Energy returns! The golden trimester. Baby starts hearing sounds and making gentle flutter kicks.";
      tips = [
        "Include calcium and iron rich meals (spinach, lentils, dairy/tofu).",
        "Gentle prenatal walking or physician-approved yoga.",
        "Talk and play soothing music to bond with your baby."
      ];
    } else if (weeks > 27) {
      trimester = 3;
      sizeDesc = "Watermelon 🍉";
      desc = "Final nesting and rapid baby weight gain. Your body is gently preparing for safe delivery.";
      tips = [
        "Practice deep pelvic breathing & 4-7-8 calming exercises.",
        "Pack your hospital maternity bag with essentials.",
        "Keep emergency contacts and doctor helpline on speed dial."
      ];
    }

    pregWeekTitle.textContent = `Week ${weeks} (Trimester ${trimester})`;
    pregBabySize.textContent = `Approx. Size: ${sizeDesc}`;
    pregDescription.textContent = desc;

    pregTipsList.innerHTML = tips.map(t => `<li>${escapeHtml(t)}</li>`).join("");
  });

  // ---------------------------------------------------------
  // 9. DAILY ROUTINES & MINDFUL TASKS
  // ---------------------------------------------------------
  const taskList = document.getElementById("taskList");
  const routineForm = document.getElementById("routineForm");
  const newTaskInput = document.getElementById("newTaskInput");
  const taskCategory = document.getElementById("taskCategory");
  const tasksPercent = document.getElementById("tasksPercent");
  const filterBtns = document.querySelectorAll(".routine-tabs-filter .filter-btn");

  filterBtns.forEach(btn => {
    btn.addEventListener("click", () => {
      filterBtns.forEach(b => b.classList.remove("active"));
      btn.classList.add("active");
      state.activeTaskFilter = btn.dataset.filter;
      renderTasks();
    });
  });

  function renderTasks() {
    if (!taskList) return;
    taskList.innerHTML = "";

    const total = state.tasks.length;
    const completedCount = state.tasks.filter(t => t.completed).length;
    const pct = total === 0 ? 0 : Math.round((completedCount / total) * 100);
    tasksPercent.textContent = `${pct}%`;

    const filtered = state.tasks.filter(t => {
      if (state.activeTaskFilter === "completed") return t.completed;
      if (state.activeTaskFilter === "pending") return !t.completed;
      return true;
    });

    if (filtered.length === 0) {
      taskList.innerHTML = `<li style="text-align:center; padding:18px; color:var(--text-muted); font-size:0.9rem;">No tasks found in this view.</li>`;
      return;
    }

    filtered.forEach(task => {
      const li = document.createElement("li");
      li.className = `task-card ${task.completed ? "completed" : ""}`;
      li.innerHTML = `
        <div class="task-left">
          <div class="custom-checkbox" data-task-toggle="${task.id}" title="Toggle complete">
            ${task.completed ? '<svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="#FFF" stroke-width="3"><polyline points="20 6 9 17 4 12"/></svg>' : ''}
          </div>
          <span class="task-label-text">${escapeHtml(task.text)}</span>
          <span class="task-cat-badge">${escapeHtml(task.category)}</span>
        </div>
        <button class="del-btn" data-task-del="${task.id}" title="Delete task">&times;</button>
      `;
      taskList.appendChild(li);
    });
  }
  renderTasks();

  taskList?.addEventListener("click", (e) => {
    const toggleBox = e.target.closest("[data-task-toggle]");
    if (toggleBox) {
      const id = parseInt(toggleBox.dataset.taskToggle, 10);
      const t = state.tasks.find(item => item.id === id);
      if (t) {
        t.completed = !t.completed;
        safeSetJSON("aanchal_tasks", state.tasks);
        renderTasks();
      }
      return;
    }

    const delBtn = e.target.closest("[data-task-del]");
    if (delBtn) {
      const id = parseInt(delBtn.dataset.taskDel, 10);
      state.tasks = state.tasks.filter(item => item.id !== id);
      safeSetJSON("aanchal_tasks", state.tasks);
      renderTasks();
    }
  });

  routineForm?.addEventListener("submit", (e) => {
    e.preventDefault();
    const text = newTaskInput.value.trim();
    const category = taskCategory.value;
    if (!text) return;

    state.tasks.unshift({
      id: Date.now(),
      text,
      category,
      completed: false
    });
    safeSetJSON("aanchal_tasks", state.tasks);
    newTaskInput.value = "";
    renderTasks();
  });

  // ---------------------------------------------------------
  // 10. BREATHE & CALM (4-7-8 GUIDED BREATH TIMER)
  // ---------------------------------------------------------
  const breathCircle = document.getElementById("breathCircle");
  const breathPhaseText = document.getElementById("breathPhaseText");
  const breathTimerNum = document.getElementById("breathTimerNum");
  const breathInstruction = document.getElementById("breathInstruction");
  const startBreathBtn = document.getElementById("startBreathBtn");
  const stopBreathBtn = document.getElementById("stopBreathBtn");

  let breathInterval = null;
  let breathRunning = false;

  startBreathBtn?.addEventListener("click", startBreathingExercise);
  stopBreathBtn?.addEventListener("click", stopBreathingExercise);

  function startBreathingExercise() {
    breathRunning = true;
    startBreathBtn.style.display = "none";
    stopBreathBtn.style.display = "inline-block";

    runBreathCycle();
  }

  function stopBreathingExercise() {
    breathRunning = false;
    clearTimeout(breathInterval);
    startBreathBtn.style.display = "inline-block";
    stopBreathBtn.style.display = "none";

    breathCircle.className = "breath-circle";
    breathPhaseText.textContent = "Ready";
    breathTimerNum.textContent = "";
    breathInstruction.textContent = "Click Start to begin Aanchal's calming breath exercise.";
  }

  function runBreathCycle() {
    if (!breathRunning) return;

    // Phase 1: Inhale (4s)
    breathCircle.className = "breath-circle inhale";
    breathPhaseText.textContent = "Inhale";
    breathInstruction.textContent = "Inhale deeply through your nose... expanding your belly.";
    countdownTimer(4, () => {
      if (!breathRunning) return;

      // Phase 2: Hold (7s)
      breathCircle.className = "breath-circle hold";
      breathPhaseText.textContent = "Hold";
      breathInstruction.textContent = "Gently retain the breath... peaceful stillness.";
      countdownTimer(7, () => {
        if (!breathRunning) return;

        // Phase 3: Exhale (8s)
        breathCircle.className = "breath-circle exhale";
        breathPhaseText.textContent = "Exhale";
        breathInstruction.textContent = "Release smoothly through your mouth... letting go of all stress.";
        countdownTimer(8, () => {
          if (!breathRunning) return;
          // Repeat cycle
          runBreathCycle();
        });
      });
    });
  }

  function countdownTimer(seconds, onComplete) {
    let current = seconds;
    breathTimerNum.textContent = current;

    function step() {
      if (!breathRunning) return;
      current--;
      if (current > 0) {
        breathTimerNum.textContent = current;
        breathInterval = setTimeout(step, 1000);
      } else {
        breathTimerNum.textContent = "";
        onComplete();
      }
    }
    breathInterval = setTimeout(step, 1000);
  }

  // ---------------------------------------------------------
  // 11. CARE GUIDE & REMEDIES ENCYCLOPEDIA
  // ---------------------------------------------------------
  const guideData = [
    {
      icon: "🍵",
      title: "Warm Ajwain & Ginger Infusion",
      category: "Digestion & Cramps",
      text: "Boil half a teaspoon of carom seeds (ajwain) and freshly crushed ginger in 2 cups of water until reduced. Excellent for easing stomach spasms, morning gas, and menstrual discomfort.",
      footer: "Safe & soothing natural remedy"
    },
    {
      icon: "🥑",
      title: "First & Second Trimester Iron Foods",
      category: "Maternal Nutrition",
      text: "Boost hemoglobin naturally: eat steamed beetroot salad, cooked spinach (palak), roasted sesame jaggery laddus, and lentils. Pair with vitamin C (lemon) for maximum iron absorption.",
      footer: "Improves blood vitality"
    },
    {
      icon: "🌙",
      title: "Golden Turmeric Moon Milk",
      category: "Deep Rest & Sleep",
      text: "Warm milk with a pinch of organic turmeric, cardamom, and nutmeg (jaiphal). Promotes natural sleep hormones, eases muscle soreness, and settles night restlessness.",
      footer: "Bedtime relaxation ritual"
    },
    {
      icon: "🌸",
      title: "Gentle Morning Pelvic Opening",
      category: "Women's Wellness",
      text: "5 minutes of Baddha Konasana (Butterfly posture) and gentle Cat-Cow stretches ease lower back tension, promote pelvic circulation, and relieve postural stiffness.",
      footer: "5-10 minutes daily"
    },
    {
      icon: "🍋",
      title: "Natural Morning Nausea Relief",
      category: "Pregnancy Comfort",
      text: "Keep dry ginger biscuits or roasted dry makhana by your bed. Chew slowly before putting your feet on the floor. Inhale fresh lemon peels when waves of nausea arise.",
      footer: "Fast nausea relief"
    },
    {
      icon: "🌿",
      title: "Tulsi & Mulethi Throat Soother",
      category: "Immunity & Cold",
      text: "Simmer fresh holy basil leaves (tulsi) and a piece of licorice root (mulethi) in water. Relieves dry cough, clears nasal pathways, and soothes throat tickle without harsh chemicals.",
      footer: "Immune support"
    }
  ];

  const guideCardsGrid = document.getElementById("guideCardsGrid");
  const guideSearchInput = document.getElementById("guideSearchInput");

  function renderGuide(items) {
    if (!guideCardsGrid) return;
    guideCardsGrid.innerHTML = "";

    if (items.length === 0) {
      guideCardsGrid.innerHTML = `<p style="grid-column:1/-1; text-align:center; color:var(--text-muted); padding:30px;">No matching care remedies found. Try searching for 'nausea', 'iron', 'sleep', or 'tea'.</p>`;
      return;
    }

    items.forEach(card => {
      const div = document.createElement("div");
      div.className = "guide-item-card";
      div.innerHTML = `
        <div class="guide-item-top">
          <span class="guide-item-icon">${card.icon}</span>
          <span class="guide-tag">${escapeHtml(card.category)}</span>
        </div>
        <h4 class="guide-item-title">${escapeHtml(card.title)}</h4>
        <p class="guide-item-text">${escapeHtml(card.text)}</p>
        <div class="guide-item-footer">✨ ${escapeHtml(card.footer)}</div>
      `;
      guideCardsGrid.appendChild(div);
    });
  }
  renderGuide(guideData);

  guideSearchInput?.addEventListener("input", (e) => {
    const term = e.target.value.toLowerCase().trim();
    if (!term) {
      renderGuide(guideData);
      return;
    }
    const filtered = guideData.filter(d => 
      d.title.toLowerCase().includes(term) ||
      d.category.toLowerCase().includes(term) ||
      d.text.toLowerCase().includes(term)
    );
    renderGuide(filtered);
  });

  // ---------------------------------------------------------
  // 12. SOS EMERGENCY SHIELD & SIREN AUDIO
  // ---------------------------------------------------------
  const sosBtn = document.getElementById("sosBtn");
  const sosModal = document.getElementById("sosModal");
  const closeSosBtn = document.getElementById("closeSosBtn");
  const sirenSoundBtn = document.getElementById("sirenSoundBtn");
  const sirenBtnText = document.getElementById("sirenBtnText");
  const sendLocationAlertBtn = document.getElementById("sendLocationAlertBtn");
  const sosLocationInfo = document.getElementById("sosLocationInfo");

  const guardianNameInput = document.getElementById("guardianNameInput");
  const guardianPhoneInput = document.getElementById("guardianPhoneInput");
  const saveGuardianBtn = document.getElementById("saveGuardianBtn");
  const guardianStatusNote = document.getElementById("guardianStatusNote");

  // Load saved guardian
  if (state.guardian && state.guardian.name) {
    guardianNameInput.value = state.guardian.name;
    guardianPhoneInput.value = state.guardian.phone;
    guardianStatusNote.textContent = `Active Guardian: ${state.guardian.name} (${state.guardian.phone})`;
  }

  saveGuardianBtn?.addEventListener("click", () => {
    const name = guardianNameInput.value.trim();
    const phone = guardianPhoneInput.value.trim();
    if (!name || !phone) {
      alert("Please provide both a name and phone number.");
      return;
    }
    state.guardian = { name, phone };
    safeSetJSON("aanchal_guardian", state.guardian);
    guardianStatusNote.textContent = `Active Guardian: ${name} (${phone})`;
    alert("Guardian details saved securely.");
  });

  sosBtn?.addEventListener("click", openSosModal);
  closeSosBtn?.addEventListener("click", closeSosModal);

  function openSosModal() {
    sosModal.classList.add("open");
  }

  function closeSosModal() {
    sosModal.classList.remove("open");
    stopSiren();
  }

  // Web Audio Synthetic Siren (No external mp3 needed)
  let audioCtx = null;
  let sirenOsc = null;
  let sirenGain = null;
  let sirenInterval = null;
  let isSirenOn = false;

  sirenSoundBtn?.addEventListener("click", () => {
    if (isSirenOn) {
      stopSiren();
    } else {
      startSiren();
    }
  });

  function startSiren() {
    try {
      const AudioContext = window.AudioContext || window.webkitAudioContext;
      audioCtx = new AudioContext();

      sirenOsc = audioCtx.createOscillator();
      sirenGain = audioCtx.createGain();

      sirenOsc.type = "sawtooth";
      sirenOsc.frequency.setValueAtTime(650, audioCtx.currentTime);

      sirenGain.gain.setValueAtTime(0.25, audioCtx.currentTime);
      sirenOsc.connect(sirenGain);
      sirenGain.connect(audioCtx.destination);
      sirenOsc.start();

      let toggle = false;
      sirenInterval = setInterval(() => {
        if (!audioCtx) return;
        toggle = !toggle;
        sirenOsc.frequency.linearRampToValueAtTime(toggle ? 980 : 650, audioCtx.currentTime + 0.3);
      }, 350);

      isSirenOn = true;
      sirenSoundBtn.classList.add("playing");
      sirenBtnText.textContent = "Stop Siren";
    } catch (e) {
      alert("Audio siren could not be initialized.");
    }
  }

  function stopSiren() {
    if (sirenInterval) clearInterval(sirenInterval);
    if (sirenOsc) {
      try {
        sirenOsc.stop();
        sirenOsc.disconnect();
      } catch (e) {}
    }
    if (audioCtx) {
      try { audioCtx.close(); } catch (e) {}
      audioCtx = null;
    }
    isSirenOn = false;
    sirenSoundBtn.classList.remove("playing");
    sirenBtnText.textContent = "Sound Safety Siren";
  }

  // Share GPS Location
  sendLocationAlertBtn?.addEventListener("click", () => {
    sosLocationInfo.style.display = "block";
    sosLocationInfo.textContent = "Acquiring your precise GPS coordinates...";

    if (!navigator.geolocation) {
      sosLocationInfo.innerHTML = "<strong>Location Alert:</strong> Geolocation not supported. Emergency message dispatched.";
      return;
    }

    navigator.geolocation.getCurrentPosition(
      (pos) => {
        const lat = pos.coords.latitude.toFixed(5);
        const lon = pos.coords.longitude.toFixed(5);
        const mapsLink = `https://maps.google.com/?q=${lat},${lon}`;

        let guardianText = "";
        if (state.guardian && state.guardian.phone) {
          guardianText = `<br><a href="sms:${state.guardian.phone}?body=EMERGENCY! I need immediate help. My location: ${encodeURIComponent(mapsLink)}" style="display:inline-block; margin-top:8px; color:var(--primary); font-weight:700;">📲 Send SMS Alert to ${escapeHtml(state.guardian.name)}</a>`;
        }

        sosLocationInfo.innerHTML = `
          <strong>📍 Coordinates:</strong> Lat ${lat}, Lon ${lon}<br>
          <a href="${mapsLink}" target="_blank" rel="noopener" style="color:var(--secondary); text-decoration:underline;">View on Google Maps</a>
          ${guardianText}
        `;
      },
      () => {
        // Fallback simulation
        const fallbackLink = "https://maps.google.com/?q=28.6139,77.2090";
        sosLocationInfo.innerHTML = `
          <strong>Location Status:</strong> Satellite signal simulated.<br>
          <a href="${fallbackLink}" target="_blank" rel="noopener" style="color:var(--secondary); text-decoration:underline;">View Emergency Map Coordinates</a>
        `;
      },
      { timeout: 7000 }
    );
  });

  // Modal Backdrop Click
  window.addEventListener("click", (e) => {
    if (e.target === sosModal) closeSosModal();
    if (e.target === addMedModal) addMedModal.classList.remove("open");
  });
});
